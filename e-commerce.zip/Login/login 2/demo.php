<!DOCTYPE html>
<html>

<body>

    <?php
    $txt = "PHP";
    echo "I love $txt!";
    ?>

</body>

</html>